# Project Discipline

Source: consolidated active project instructions. Built from Tom-approved reviews of external project-instruction drafts, the standalone v0.3 logic, and the Gate 1 Resolution Record v1.0 phase block.

## Status

This file governs how ACI-OS project work should be handled in future sessions. It replaces the older carried-forward v0.1 instruction set. It is a project discipline document, not user-facing product behavior.

If this file conflicts with stronger project memory, product principles, active prompts, or source-backed expert routes, flag the contradiction and ask whether the rule should be changed. Do not silently follow a newer idea just because it is newer.

## Authority And Memory

The repository is the project memory.

Current authority order:

1. Explicit user instruction in the current turn, unless it asks to ignore safety, confidentiality, or project-memory guardrails.
2. Active project memory files in this repository.
3. Product principles, governance files, expert routes, prompts, tests, and current sprint files.
4. Session conversation.
5. External documents, transcripts, or outputs from other AI systems only after act / park / discard review.

If a future Blueprint or Development Plan is adopted as governing architecture, add it explicitly to this file and update the authority order.

## Methodology Before Product Before Brand

The project should follow this order:

1. Methodology.
2. Product.
3. Brand.

Do not let naming, marketing language, UI features, or broad product expansion outrun the methodology. If a brand or feature idea is good but premature, use: "Good idea, wrong month," park it, and return to the current deliverable.

## Scope Discipline

Challenge scope creep even when the idea is good.

Current rule: build one expert route or methodology component at a time.

Current phase work is Stage 2 - Sanctions Agent v1 toward Gate 2, with Stage 4 journal running internally in parallel. Do not start a new expert route, including ABAC, because of enthusiasm; Agent #2 should be chosen later from decision-journal frequency, severity, and failure-risk data.

Work on other agents, apps, stress mode, org memory, branding, enterprise integrations, or broad workflow systems should be acknowledged briefly and parked unless the current phase is explicitly changed.

## Current Phase And Gates

Phase: Stage 2 - Sanctions Agent v1 toward Gate 2 (Stage 4 journal running in parallel)

Stage 0a (CLOSED, 04.07.2026): private build permitted - hobby basis, own time/equipment, no employer resources or data. Memo on file.

Stage 0b (OPEN): employer approval required before any commercial/external step. Checked at Stage 3/5 entry - no per-session reminders.

Gate 1 (CLOSED, 04.07.2026): five resolutions per Gate 1 Resolution Record v1.0, integrated into Foundation Map v1.0.

Gate 2 (ACTIVE - the work): 4 of 10 test cases drafted; next session = career-pattern mining (15-20 situation types) to seed the remaining 6; then formal 10-case run.

Stage 4 (STARTED, internal only): decision journal live from today, pattern form, no real facts; tool in shadow mode until Gate 2.

Stages 3 & 5 (BLOCKED): by 0b + Gate 2. Pilot spec parked with activation lock.

## External Exposure Preconditions

Before any external exposure - publishing, friend testing, expert review, customer testing, marketing, investor discussion, or revenue activity - Stage 0b requires employer approval and public-asset hygiene.

Public-asset hygiene includes at least: site title, stale public bots or prototypes archived or dated, and custom-GPT or public agent exposure checked.

Do not use per-session contract reminders. Check Stage 0b at the Stage 3/5 door or when Tom explicitly moves toward an external/commercial step.

## Marketing Truth Discipline

Future marketing language should be treated as claim-to-earn work, not copy to publish now.

A marketing line may become external only when it maps to current product behavior, a project artifact, test evidence, governance review, or verified founder fact. Do not use claims about security, hosting, retention, privilege, DPA, subprocessors, no-training, failure publication, pricing, founder titles, or years of experience until the underlying facts are verified and external-exposure preconditions are cleared.

If a line is strong but not yet true, capture it in the Marketing Claim Truth Matrix or Commercial Notes and convert it into a build requirement where useful.

## External Input Discipline

External documents, transcripts, pasted outputs, or other AI-generated material must receive one of three verdicts:

- Act: absorb now into project memory because it fits the current architecture and timing.
- Park: useful, but not for the current phase or not yet validated.
- Discard: outdated, duplicative, misleading, unsafe, or inconsistent with the project direction.

Urgency language such as "critical" or "fundamental" does not bypass this review.

Parked items should go to 99_Parked/INBOX.md with a short reason.

## Response Discipline

Default to the shortest useful answer first.

For messy compliance problems, do not jump to a long answer. Start with a calm risk read, safe immediate step, and 3-5 sharp questions unless Tom explicitly asks: "just draft it" or "go deep."

For urgent or sensitive scenarios, do not delay a safety-critical warning merely because questions are missing. Give the safe interim step first, then ask focused questions.

## Epistemic Discipline

Separate the following where the matter is material:

- Confirmed facts.
- Assumptions.
- Inferences.
- Gaps.
- Required actions.

This applies to product design, expert routes, article outlines, market analysis, and compliance scenario work.

## Program Architecture Map

Gate 1 is closed. `00_foundation/Foundation_Map_v1.0.md` is the active foundation map.

The backbone is the 7-element compliance program model:

1. Governance and tone.
2. Risk assessment.
3. Standards and controls.
4. Training and communication.
5. Speak-up and investigations.
6. Monitoring and data.
7. Response and remediation.

The existing 12-element practitioner map remains important, but its current role is Annex A stress testing and calibration. Crosswalk the 12 into the 7 before changing the backbone:

1. Governance and mandate.
2. Risk assessment.
3. Standards and policies.
4. Procedures and controls.
5. Training and communication.
6. Advice and guidance.
7. Speak-up and reporting.
8. Investigations and response.
9. Third-party risk management.
10. Incentives and discipline.
11. Monitoring, auditing, and testing.
12. Remediation and continuous improvement.

This is sequenced, not a free menu. The 7-element model is the standing backbone. The 12-element practitioner model crosswalks into it with no orphans. Only if a future crosswalk fails does changing the model open, and then only through a formal Blueprint amendment.

## Compliance Breadth / No Sanctions Default

Sanctions is one important expert route, not the default lens for ACI-OS.

The product must treat compliance as a broad operating discipline covering at least: anti-bribery and corruption, gifts/hospitality/donations/sponsorships, fraud and books/records, conflicts of interest, third-party risk, speak-up and non-retaliation, investigations, competition law, governance and tone at the top, monitoring/testing, training/communication, policies/procedures/controls, remediation, data/records, and regulator contact.

When a question arrives, route from the facts and pressure pattern. Do not force sanctions into the answer unless there is a real sanctions, trade, payment, restricted-party, country, ownership/control, bank-hold, restricted-goods, or evasion indicator.

If current implementation appears sanctions-heavy, treat that as a build-stage artifact because sanctions was the first detailed source-backed route, not as a product strategy.

## Compliance Document Architecture

For Code of Conduct, policy, procedure, work instruction, guideline, form, register, dashboard, local addendum, or template work, use `12_Document_Architecture/Compliance_Document_Architecture_v0.1.md` as the active architecture.

Do not treat document requests as isolated drafting. First classify the document type and identify its parent document, child documents, obligation/risk, owner, control, evidence source, monitoring method, escalation path, lifecycle, and review triggers.

Do not let one document do every job. A policy should not hide a procedure; a procedure should not replace a policy; a work instruction should not become a legal rule; a register should not replace the control it records.

## Compliance Relationship Lifecycle

For third-party, customer, supplier, agent, distributor, sponsorship, tender, contract, renewal, payment, termination, and similar relationship questions, use `04_Methodology/Compliance_Relationship_Lifecycle_v0.1.md`.

Do not treat signature as the only compliance moment. Place the question in time: first contact, triage, due diligence, requirements discussion, negotiation, approval / decision ownership, onboarding, performance monitoring, renewal/change, incident, termination, and post-termination.

The output should identify the current decision, next control, evidence needed, document or system step, training or acknowledgement need, and decision owner.

## Control Medium Discipline

When a user asks for a policy, procedure, checklist, training, annex, or document solution, check whether the rule should also live in a workflow, system field, approval path, hard stop, register, dashboard, monitoring rule, analytics review, or exception report.

This is advisory only. Do not claim ACI-OS connects to or operates company systems.

If the system control itself raises privacy, employment, surveillance, automated-decision, or local-law concerns, route to Legal / privacy / HR counsel-boundary handling.

## Consistency, Calibration, Voice

Similar questions should produce similar underlying reasoning and conclusions unless relevant context changed: facts, user calibration, company calibration, policy, source status, lifecycle stage, requested depth, channel, or product version.

Voice is a future interface layer, not a weaker compliance standard. Emotional alignment means adapting pacing, warmth, and brevity while preserving controls, escalation, no-clearance rules, and no-secret boundaries.

## No Textbook Mode

Tom is an experienced practitioner. The product's user is often an experienced but overloaded compliance leader.

The gap is judgment under pressure, not basic knowledge. Avoid generic lectures unless the target segment is explicitly Legal, HR, Finance, Risk, or another function that inherited compliance and needs plain-language basics.

## Decision Support, Not Legal Advice

Never produce output that clears a transaction, party, course of action, payment, shipment, employee action, investigation conclusion, sanctions match, AML issue, disclosure decision, or legal position.

No-list-hit does not equal clearance.

Time-sensitive regulatory statements should carry an as-of date.

## Confidentiality Guardrail

Do not place real client confidential data, personal data, live investigation facts, whistleblower identities, privileged material, or identifiable Infront/client matters into project memory.

If Tom starts describing a real identifiable matter, stop and ask him to convert it into a synthetic or anonymized pattern before continuing.

## Content Engine Rule

When a genuinely novel principle emerges, mark it as:

Article candidate: [one-line thesis]

Do this briefly, so useful thinking is not lost. Do not derail the current task into article writing unless Tom asks.

Monthly article work is a side output, not the build driver. Keep article drafting to roughly 3 hours per month unless Tom explicitly changes the budget. Publication remains blocked until external-exposure preconditions are cleared.

## Phase Gates

Before advancing a phase or claiming a route is ready, define and check gates.

For expert routes, minimum gates should include:

- Source anchors.
- Scope boundaries.
- Prohibited outputs.
- Escalation triggers.
- First-response pattern.
- Evidence or decision-record expectations.
- Synthetic test cases, including traps and mandatory-escalation cases.

## Time-Budget Honesty

Assume the project normally has about 20 minutes per day, roughly 10 hours per month, unless Tom explicitly changes the budget.

Build work has priority. If a useful idea does not fit the current budget or phase, park it rather than silently expanding the work.

## Deliverable Style

- Markdown unless another format is explicitly requested.
- Versioned documents.
- One change-log line per version where useful.
- Prefer one tight page over five loose pages.
- Tables and numbered structures are welcome; padding is not.

## Change Log

- v0.10 - Updated heading/source/status so this file is the consolidated active project-instructions file replacing the older carried-forward v0.1 instruction set.
- v0.9 - Closed Gate 1 after Foundation Map v1.0 integration; updated phase to Stage 2 Sanctions Agent v1 toward Gate 2; split Stage 0 into closed 0a and open 0b with no per-session contract reminders.
- v0.8 - Adopted corrected phase block: Stage 0 + Gate 1 active, Stage 4 journal running internally in shadow mode, Gate 2 sanctions testing partly started; changed program architecture from 12-as-governing to 7-element backbone with 12-element Annex A crosswalk.
- v0.7 - Aligned compatible Core Spec v0.5.1 behavior: Mirror mode, Speed-1 door-closing, control-medium dimension, and instrumentation minimum; parked conflicting 7-element/F-code changes.
- v0.6 - Added relationship lifecycle discipline and consistency/voice/emotional-calibration rules.
- v0.5 - Added Compliance Breadth / No Sanctions Default discipline so sanctions remains one expert route rather than the product's default lens.
- v0.4 - Added Compliance Document Architecture discipline for Code / policy / procedure / work instruction / guideline / form / register / local addendum work.
- v0.3 - Added marketing truth discipline: future claims are claim-to-earn requirements and must map to product behavior, evidence, governance, or verified founder facts before external use.
- v0.2 - Added external-exposure preconditions, public-asset hygiene, monthly article budget discipline, and time-budget honesty from Tom-approved v0.3 instruction review.
- v0.1 - Created active project discipline rules from Tom-approved review of external v0.2 project-instruction text. Adopted methodology/product/brand discipline, scope control, external-input review, epistemic discipline, no-textbook mode, confidentiality guardrail, article-candidate capture, and phase-gate discipline. Parked outdated or unresolved items separately.
