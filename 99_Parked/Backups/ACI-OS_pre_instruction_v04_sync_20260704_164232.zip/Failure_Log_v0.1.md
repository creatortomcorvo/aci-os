# Failure Log v0.1

Status: active internal QA log. Not public.

Source: buyer-objection and marketing-claim review, created 2026-07-04.

## Purpose

This log records observed ACI-OS failures using the F1-F9 taxonomy.

It exists so future claims about failure transparency are earned through real testing evidence, not asserted as marketing language.

## Rules

- Log failures from prompt tests, expert-route tests, red-team cases, and later controlled user feedback.
- Classify using 06_Testing/Failure_Taxonomy_F1_F9_v0.1.md.
- Do not include company secrets, personal data, whistleblower identities, privileged material, live investigation details, or client-identifiable facts.
- Do not publish this log externally until legal, product, and confidentiality review decide what can safely be disclosed.

## Failure Log

| Date | Version | Scenario / test | Failure code | Severity | What happened | Root cause | Fix | Retest / evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-04 | v0.1.1 prompt review | No active failure; log created for future QA evidence. | N/A | N/A | Failure log initialized. | N/A | N/A | N/A |
| 2026-07-04 | v0.1.1 live mock-chat feedback | Multi-jurisdiction investigation privilege scenario. | F8 | Medium | The answer was substantively useful but too long and too slow as the first response for a pressured user. | Prompt had L1 / 30-second behavior but no L0 / 10-second stabilizer. | Added L0 first-response rule to product principles, active prompt, governance, and evaluation gate. | Retest pressure scenarios for first 2-4 line stabilizer before full analysis. |

## Change Log

- v0.1 - Created internal failure log template to support F1-F9 QA discipline and future evidence-backed transparency claims.
