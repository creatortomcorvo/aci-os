# Project Journal

## 2026-07-03

- Created first Chief Consigliere prototype files.

- Created Expert Map.

- Created 15 Chief Consigliere test cases.

- Created Current Sprint file.

- Decision: ChatGPT acts as Chief AI Architect, Codex acts as Builder and Project Secretary, GitHub is the permanent knowledge base.

- Next task: Tom will show the created files to ChatGPT for architecture review.

- Confirmed active repository folder and completed temporary write-test inside ACI-OS.

- Reviewed current repository structure and project memory files.

- Created first Chief Consigliere system prompt.

- Converted the 15 Chief Consigliere test cases into a repeatable evaluation checklist with scoring rubric.

- Updated Current Sprint and Where Are We to reflect the new prompt and evaluation artifacts.

- Ran first baseline evaluation of the v0.1 system prompt: 12 pass, 3 partial, 0 fail.

- Identified three prompt refinement areas: board program effectiveness, training after repeated incidents, and isolated compliance officer traction.

- Created 06_Testing/Evaluation_Run_Chief_Consigliere_v0.1_2026-07-03.md.

- Created Chief Consigliere system prompt v0.1.1 to address board effectiveness, training-after-incident remediation, and isolated compliance officer traction.

- Ran v0.1.1 evaluation: 15 pass, 0 partial, 0 fail, 0 critical fails.

- Decision: v0.1.1 should become the active Sprint 1 prompt; next substantive work is source-backed expert route instructions, starting with Sanctions.

- Connected local ACI-OS folder to GitHub remote https://github.com/creatortomcorvo/aci-os.git and pushed the merged main branch.

- Created 05_Experts/Sanctions_Expert_Route_v0.1.md as the first source-backed expert route instruction file.

- Sanctions route source anchors: OFAC 50 Percent Rule, OFAC compliance framework, OFAC sanctions list tools, UK OFSI general and importer/exporter guidance, EU sanctions resources, Council of the EU sanctions overview, and UN Security Council Consolidated List.

- Next substantive work: build source-backed ABAC expert route instructions.

- Integrated user-provided sanctions-agent instruction into 05_Experts/Sanctions_Expert_Route_v0.1.1.md.

- The v0.1.1 sanctions route adds fact/unknown/legal/practical separation, screening category separation, Switzerland/Australia/SSI/OpenSanctions coverage guidance, ownership evidence labels, named-listing status labels, management/PEP/reputation handling, and detailed report mode.

- Captured founder/product principles in 00_Project/PRODUCT_PRINCIPLES.md: ACI-OS should be an intelligent interface for managing the compliance program, external providers, systems, business expectations, risk appetite, data protection modes, and future compliance team/training workflows.

- Added 10_Product/External_Escalation_Model_v0.1.md. This captures configurable external expert escalation, including KRUK / kruk.ch, for serious matters such as harassment, sanctions, fraud, bribery, retaliation, senior-management misconduct, regulator contact, and conflicted internal processes, with no automatic data transfer.

## 2026-07-04

- Reviewed older founder note and deliberately excluded outdated personal-brand naming ideas.

- Created 00_Project/FOUNDER_VISION.md with retained useful ideas: front-door plus specialist-agent architecture, calibration asymmetry, founder-method knowledge layering, emergency 30-second first-answer mode, stress/isolation support, human escalation concept, contributor feedback, and build-by-using strategy.

- Updated 00_Project/PRODUCT_PRINCIPLES.md and 10_Product/Chief_Consigliere_v0.1.md to reflect calibration and emergency-first-answer behavior.

- Extracted reusable founder-method logic from SGH Code of Ethics lecture PDF into 04_Founder_Method/Code_of_Ethics_Lecture_SGH_2026_03.md, focusing on code triggers, modern code design, compliance organization lessons, code review gaps, first questions, and future product ideas.

- Extracted reusable founder-method logic from the 2026 group CMS implementation lecture into 04_Founder_Method/CMS_Group_Implementation_Lecture_2026_01.md, focusing on HQ/group rollout, ICS foundation, compliance organization, risk assessment, policy design, local adaptation, monitoring/audit/investigations/reporting, geopolitical crisis logic, and future product ideas.

- Extracted reusable founder-method logic from the organizational culture of integrity lecture into 04_Founder_Method/Organizational_Culture_of_Integrity_Lecture_2026_01.md, focusing on culture layers, integrity norms, leadership modeling, accountability systems, localization without stereotyping, training adaptation, speak-up trust, monitoring, and consequence management.

- Captured founder feedback from the Chief Consigliere mock chat: business-facing replies should reframe "Compliance is blocking revenue" as a misunderstanding and a need to understand the business model better; compliance control design should follow frequency, with rare activity handled case by case and repeated risky activity embedded in written procedures, approvals, thresholds, required fields, and system controls.

- Captured the trusted compliance companion vision in 10_Product/Product_Strategy_Trusted_Companion_v0.1.md, including target customer, problem definition, first-30-seconds design, five-stage operating model, capability architecture, calibration, founder method, community scenario learning, business model staging, and judgment transparency.

- Captured product-category and governance logic in 10_Product/Compliance_Product_Category_And_Governance_v0.1.md. The file frames ACI-OS as a human-supervised compliance decision-support and escalation tool, defines intended-use boundaries, product prohibitions, decision-record standards, knowledge governance, data-protection baseline, whistleblowing boundary, MVP controls, and official governance source anchors.
- Captured European market-positioning logic in 10_Product/European_Market_Positioning_v0.1.md. The strategic wedge is under-resourced compliance leaders in European or Europe-based international mid-market and upper-mid-market companies who need structured judgment for difficult compliance decisions, not basic compliance education.

- Created 00_Project/PROJECT_DISCIPLINE.md after Tom approved the act/park/discard review of external project-instruction text. Active rules now include methodology-before-product-before-brand, scope discipline, external-input review, no-textbook mode, epistemic discipline, confidentiality guardrails, article-candidate capture, and phase-gate discipline.
- Created 99_Parked/INBOX.md for useful but not-yet-active items, including the exact Blueprint/Development Plan authority structure, sanctions-only phase wording, employment-contract reminder, 7-element model adoption, and later product features such as stress mode, org memory, and branding.

- Captured calibration refinement in 10_Product/Calibration_Model_v0.1.md: the Legal Counsel wearing Compliance Hat is a major potential target group. This user is capable but may panic when suddenly responsible for speak-up, monitoring, risk assessment, tone at the top, third-party management, training, investigations, remediation, and board reporting.
- Article candidate: "The Legal Counsel Wearing the Compliance Hat" - the hidden European market is capable lawyers suddenly expected to operate compliance without a senior compliance sparring partner.

- Captured Adaptive Compliance Intelligence and Professional Navigation in 10_Product/Adaptive_Compliance_Intelligence_v0.1.md: company-profile-aware answers, database-versus-judgment positioning, first-screen psychological orientation, and qualitative stress/confidence/navigation logic.
- Promoted the 100 Compliance Moments concept into 04_Methodology/100_Compliance_Moments_Discovery_v0.1.md. Next methodology step is to map the first 25 moments before building another isolated expert route.
- Parked product modes and homepage copy in 99_Parked/INBOX.md until methodology and product behavior are clearer.
- Article candidate: "The 100 Moments That Make a Compliance Officer Reach for the Phone" - build compliance technology around the moments of pressure, not the list of regulations.

- Captured external-testing disclaimer principle: future friend/expert/customer testing must use a controlled no-secret tester pack, not the raw repository and not live company matters. Added disclaimers to product governance, product principles, and created 10_Product/No_Secret_Tester_Pack_Future_Draft_v0.1.md as a placeholder.
- Reviewed external v0.3 standalone instructions. Acted on the specialized interaction notice, 22:30 North Star, crisis-first behavior, layered-depth default, external-exposure hygiene, and monthly article/time-budget discipline; parked the 7-element backbone change and exact stage-gate authority because current project memory has not adopted them.
- Captured security/paranoia note as product architecture: created 10_Product/Pattern_First_Input_Layer_v0.1.md and updated product principles, governance, active prompt, current sprint, and tester-pack placeholder so no-secret mode asks for patterns, roles, risk facts, and pending decisions before names or identifiers. Parked broader security-as-commercial-moat ideas in 99_Parked/Commercial_Notes.md.
- Captured buyer-objection note as architecture and parked commercial narrative: created 10_Product/Reasoning_Record_v0.1.md and 06_Testing/Failure_Taxonomy_F1_F9_v0.1.md; updated product principles, governance, active prompt, evaluation checklist, and current sprint. Parked approval-kit, no-lock-in, user-promotability, private-sparring, and counsel-hours pricing ideas in commercial notes.
- Reviewed fourteen-line marketing canon and converted it into claim-to-earn discipline: created 10_Product/Marketing_Claim_Truth_Matrix_v0.1.md and 06_Testing/Failure_Log_v0.1.md; updated project discipline, product principles, current sprint, commercial notes, and parked all public marketing use until external-exposure preconditions and evidence are ready.

- Captured live mock-chat feedback that the first answer must be faster and shorter. Added L0 / 10-second first-response behavior: stop, relax, avoid irreversible action, safe immediate direction, then offer deeper structure. Logged the prior long first response as F8 poor usability under pressure.

- Captured founder note on Consigliere delta mechanisms: the product wins by disciplined behavior and subtraction, not by claiming to know more than raw models. Created Consigliere_Delta_Mechanisms_v0.1 and Raw_vs_Consigliere_Baseline_Tests_v0.1, with no-hit distributor screening as the first clearance-trap case.

- Implemented frozen payment plus substitute-route scenario as a sanctions / financial-crime evasion-risk pattern. Added it as Case 02 in the raw-vs-Consigliere baseline tests, added a sanctions-route response template, updated the active prompt, and formalized the Speed 1 / Speed 2 response pattern.

- Implemented three additional dual-speed adversarial cases: stale-screen auto-renewal, written-blessing commercial agent / conditions memo, and suspected dual-use diversion requiring stop-typing and counsel-controlled handling. Updated raw-vs-Consigliere baseline tests, sanctions route, active prompt, product principles, and delta mechanisms.

- Captured five-mode question router: Crisis, Judgment Call, Counsel-Boundary, Program Self-Assessment, and Escalation-Mandatory. Created Question_Mode_Router_v0.1 and Question_Inventory_v0.1 scaffold, updated active prompt, product principles, 100 moments template, sprint, commercial notes, and article pipeline. Later clarified that the fixed 40-question framing was a mistake; the inventory should collect useful router-training questions over time.

- Corrected the question inventory after Tom clarified the fixed 40-question framing was a mistake. Kept the five-mode router and converted Question_Inventory_v0.1 into an open router-training inventory seeded with accepted scenarios.

- Captured 15 response pattern cards as a methodology library for five-mode answer shapes. Created 04_Methodology/Response_Pattern_Cards_v0.1.md, linked it from the router and inventory, corrected the proposed path, removed seven-element numeric shorthand, and kept counsel-boundary / self-reporting cards as structured handoffs rather than legal answers.

- Captured proportional rendering refinement: consistency means invariant reasoning, not identical visible scaffolding. Created 04_Methodology/Response_Pattern_Cards_v0.2.md with minimum facts, status fork, evidence, output labels, public-sector / sports-body lens, tone layers, revised skeleton, and consistency index. Extended F7 to cover template inflation and added a trivial EUR 30 notebook test case.

- Captured role-boundary feedback from the advice-vs-approval mock question. Added the Role-Boundary and Capture Principle, updated the active prompt with mandate check, misquote test, same-day written correction, colleague-voice script, plain-yes trigger, and one-line record suggestion. Added Raw-vs-Consigliere Case 07 and a matching question-inventory row.

- Captured triage-layer design note. Created 04_Methodology/Triage_Layer_Spec_v0.1.md, updated product principles and active prompt with situation picker, request-type echo, provisional severity without green, tool-chosen 2-4 triage questions, "don't know" and free text handling, and instrumentation for "something else." Added Raw-vs-Consigliere Case 08 for the green-clearance-leak trap.

- Captured user memory question as product architecture. Created 10_Product/User_Memory_And_Recall_Model_v0.1.md and updated product principles/current sprint. Memory is planned, but as controlled layers: user/role profile, company profile, conversation recall, matter/decision memory, and learning/pattern memory. No-secret mode stays abstracted; secure company-material mode requires security, access, retention, deletion/export, audit logs, and no-clearance guardrails.

- Captured Decision Front Door v2 recommendation. Created 04_Methodology/Decision_Front_Door_Spec_v0.1.md and made it the active front-door refinement. Updated product principles, active prompt, mode router, question inventory, raw-vs tests, failure taxonomy, sprint, and status docs. Active changes: timing is a standing live-matter question; role-boundary echo has six labels; output menu has five choices; pressure detector runs under the surface; controlled color replaces the absolute no-green rule. Advisory green is allowed only where there is no live decision; routine green is earned only after triage with no-clearance microcopy. Unearned green on a live matter remains a clearance failure.

- Captured durable compliance-document architecture as core structure. Created 12_Document_Architecture/Compliance_Document_Architecture_v0.1.md and 12_Document_Architecture/Template_Pack_Index_v0.1.md. Added product principle and prompt behavior: document requests are architecture requests first, not one-off drafting; classify Code / policy / procedure / work instruction / guideline / form / register / local addendum, then identify parent/child lineage, obligation, owner, control, evidence, monitoring, escalation, lifecycle, and review triggers. Parked full source-backed template pack and document-management implementation.

- Implemented "The Twentieth Basket" as Raw-vs-Consigliere Case 09 and Question_Inventory row 12. The case tests earned green, split verdicts, routine proportionality, ABAC/state-owned entity routing, practical redesign, and the rule that "same as every year" can be accumulation rather than comfort. Corrections: use F1 for unearned green, F6 for missed routing, no hard-coded date, and cautious public-official wording.

- Added explicit Compliance Breadth / No Sanctions Default rule after Tom flagged that compliance is broader than sanctions. Updated project discipline, product principles, active prompt, Expert Map, and current sprint. Active rule: sanctions is one expert route, not the product's default lens; route from facts and pressure patterns across ABAC, gifts/hospitality, fraud/books-records, conflicts, third-party risk, speak-up, investigations, competition, governance, monitoring, training, documents, controls, remediation, data/records, and regulator contact.

- Captured critical founder needs on consistency, voice, emotional calibration, freemium, slogan, and lifecycle. Acted on product behavior now: similar questions should produce similar reasoning unless facts/calibration/source/product context changes; future voice is an interface layer that preserves no-clearance/no-secret/escalation standards; emotional alignment adapts pacing and tone without lowering controls. Created 04_Methodology/Compliance_Relationship_Lifecycle_v0.1.md so relationship and contract questions are handled from first contact through post-termination. Added "Think Like Compliance" to the claim-to-earn matrix and parked freemium pricing in commercial notes.

- Captured Tom's priority that ACI-OS must emphasize the different roles and perspectives of Legal Counsel and Compliance Officer. Created 04_Methodology/Legal_Compliance_Role_Boundary_v0.1.md and updated product principles, active prompt, calibration model, question inventory, expert map, sprint, status, history, and handoff. Active rule: split Legal hat, Compliance hat, management hat, HR/Audit ownership, and external counsel handoff instead of blending them.

- Reviewed external Core Specification v0.5.1. Aligned compatible behavior while preserving current repo memory and Tom-approved concepts. Created 04_Methodology/Consigliere_Core_Spec_v0.5.1_Alignment_Review.md, 04_Methodology/Control_Medium_Dimension_v0.1.md, and 06_Testing/Instrumentation_Minimum_v0.1.md. Updated mode router to add Mode 6 Mirror, added Speed-1 door-closing rule, updated active prompt/product principles/project discipline/sprint/status/handoff. Parked 7-element model transition, F-code remapping, full crisis-header library, embedded-controls source pack, and sanctions-folder reorganization.

- Accepted Tom's corrected phase/status block. Active phase is Stage 0 + Gate 1, with Stage 4 journal running internally in parallel. Stage 0 contract/IP/side-activity/conflict check blocks external exposure but not internal build or journal. Gate 1 is sequenced: crosswalk the 12-element practitioner map into the 7-element backbone as Annex A; change the model only if the crosswalk fails and only through a Blueprint amendment. Gate 2 sanctions testing is partly started; tool use remains shadow mode until Gate 2 passes. Updated discipline, sprint, status, router templates, instrumentation, European market positioning, parked inbox, history, and handoff.
