# Consigliere Pilot — Calibration & Feedback Specification v0.1
**Repo location:** `99_parked/pilot_spec_v0.1.md` — moves to active build ONLY when the activation conditions below are met.
**⛔ ACTIVATION CONDITIONS (Codex: do not implement the deployed/link version before all three):** Gate 1 closed · Gate 2 closed (Sanctions agent passes 10-case library) · Stage 0 confirmed by Tom (employment contract cleared — external testers are external exposure). Building the form/flow as dormant code is permitted; issuing links is not.

## 1. Purpose
Closed pilot for 3–5 trusted compliance professionals (Stage 5 cohort profile: small-team operator or dual-hat GC, CHF/EUR 0.5–5bn, cross-border, pharma/life-sciences or sports/media preferred). Goal: test whether the Consigliere delivers useful first guidance and reduces uncertainty — NOT whether it gives legal answers. Pilot tests the behavior defined in `Consigliere_Core_Spec_v0.5.1` exactly; this document defines the wrapper (calibration, limits, feedback, reporting), never the answer format.

## 2. Landing page
Title: **Kruk Consigliere — Pilot** (working name; final naming is Brand-stage).
Disclaimer (verbatim, must be accepted via checkbox before start):
> This is a testing environment. Do not enter company names, personal names, confidential information, trade secrets, investigation details, or privileged information. Describe situations as anonymized patterns — the tool is designed to work fully without identifying facts. Conversations may be reviewed in anonymized form to improve the tool. This tool provides decision support, not legal advice, and never "clears" anything.
Buttons: [I understand — start calibration] · [What this tool will never do] (opens the not-do list from Core Spec §13, user-facing wording).
Testers additionally sign the onboarding pack (pattern-abstraction one-pager + journal commitment) BEFORE receiving the link — no journal, no access (Dev Plan Stage 5 rule).

## 3. Calibration (≤3 minutes, all closed answers, stored as the §2.5 calibration profile)

**A. About you**
- Role: Head of Compliance · Compliance Manager · Legal Counsel with compliance hat · CFO/Finance with compliance hat · Other
- Experience: 0–3 · 4–7 · 8–15 · 15+ years
- Main pressure today (multi-select, max 2): too many topics · no team · CEO/business pressure · unclear escalation · need a second opinion
*(Feeds tone calibration and Mirror-mode readiness; "main pressure" maps to the position-question set.)*

**B. About the company**
- Size: <250 · 250–1,000 · 1,000–5,000 · 5,000+ employees
- Industry: pharma/healthcare · sports/media · financial services · manufacturing · technology · other
- Footprint: domestic · Europe · global · high-risk markets involved
- Regulatory vocabulary (auto-derived from industry+footprint, confirm with user): CMS/IDW PS 980 (DACH) · adequate procedures (UK) · ECCP/FCPA (US-connected) · mixed

**C. Compliance setup**
- Reporting line: CEO · GC/Legal · CFO · Board/Audit Committee · other
- Team size: only me · 2–3 · 4–10 · 10+
- What exists today (multi-select): Code of Conduct · speak-up channel · investigation procedure · third-party DD · sanctions screening · training program · monitoring plan
*(The "exists today" list = seed for control-medium advice (§9): tool may reference which of these are paper vs. system.)*

## 4. Usage limits
- **5 questions per user per day** (cost control, quality forcing, cleaner data). Counter visible ("3 of 5 left today"). "Go deeper" clicks on the same matter do NOT consume a question; new matters do.
- Session answers render per Core Spec front door: role label · color (v2 rules, incl. no unearned green) · first answer · tool-selected triage questions · five-output menu. No pilot-specific answer template exists.

## 5. Feedback design (two layers — fatigue-proofed)

**Layer 1 — after every answer (2 taps, ≤5 seconds):**
- Useful? ①②③④⑤
- Optional single issue chip (maps to failure taxonomy): felt overconfident (→F4) · missed/wrong escalation point (→F5) · too long / lectured me (→F7/F9) · wrong or missing questions (→question-bank log) · sources/dates doubtful (→F1/F2) · wanted approval language it refused to give (→ logged as F6-pressure event, this is the tool WORKING) · other (≤300 chars)

**Layer 2 — weekly (once, ~90 seconds, closed):**
- Did the tool reduce your uncertainty this week? ①②③④⑤ *(mission metric)*
- **Would you have used this alone at 22:30 on a real matter? yes · maybe · no** *(North Star metric)*
- Answers were: too short · right · too long
- What should improve (max 2): more practical steps · more legal basis · more executive wording · more industry context · better escalation guidance · faster/shorter · other
- Anything important missing? (≤300 chars)

## 6. Auto-telemetry (logged per interaction, no user effort)
mode rendered (M1–M6) · color(s) rendered incl. earned-green events · depth reached (L1–L4) · elements tagged · question category (from situation picker) · triage questions asked/answered/skipped/don't-know · "go deeper" clicked y/n · device class · time of day · response latency · daily-limit hit y/n. Joined with Layer-1 feedback per answer. This telemetry IS the §10 instrumentation applied to testers; it flows into the same stats as Tom's decision journal, tagged by anonymous user ID (tester-1, tester-2…).

## 7. Data the pilot must NOT collect (hard rules)
No user names · no company names · no email beyond the invite mechanism (held outside the app) · no documents/uploads (feature disabled entirely in pilot) · no free-text calibration · no IP-based geolocation storage · question text stored ONLY after the input layer's pattern-abstraction coaching has run (Core Spec §13); if identifying data slips through, reviewer redacts before any analysis and logs a confidentiality incident (Gate 5 KPI: zero).
Commercial version note (for later, not pilot): document upload and company-specific knowledge = paid tier, with proper security architecture — parked in `99_parked/commercial_notes.md`.

## 8. Developer report (auto-assembled, weekly, per tester and aggregate)
```
Tester: tester-2 (Legal Counsel w/ compliance hat · pharma · 1,000–5,000 · reports to GC · team: only me)
Week: N · Questions: 14 · Modes: M2×9, M3×3, M6×2 · Depth: L1-only 64% · Colors: amber×6, earned-green×3, red×1
Usefulness avg: 4.3 · Uncertainty: 4/5 · 22:30 test: maybe
Issue chips: F7×2 (both on M4 answers) · question-bank flags×1
Auto-flags: earned-green rendered correctly ×3 (no F6-color) · escalation fired ×1, confirmed correct
Suggested actions (rule-generated, human-decided): review M4 proportionality (2×F7 same mode) · add question [x] to Bank B (skipped-but-needed pattern)
```
"Suggested actions" are generated by simple rules (repeat F-class in same mode → review that mode's template; skipped-question patterns → bank edit candidate) and land as INPUTS to the monthly mini-review — a human decides, per Hard Constraint 6. The pilot suggests; Tom disposes.

## 9. Pilot exit criteria (mirrors Gate 5)
Both/all testers: 22:30 test "yes" unprompted by week 6 · zero confidentiality incidents · usefulness trend flat-or-up · element-frequency distribution captured per tester (generalization evidence vs. Tom's journal). Failure to meet = iterate, don't expand the cohort.

---
*Change log: v0.1 — initial pilot spec. Aligned to Core Spec v0.5.1 (no format fork); feedback mapped to failure taxonomy; two-layer fatigue-proofed feedback; auto-telemetry over questionnaires; North Star measured weekly; activation gated on Gates 1–2 + Stage 0.*
