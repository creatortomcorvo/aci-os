# Career Pattern Mining v0.1 — Gate 2 Seed File
**Source:** Tom's pattern dump, 04.07.2026, pattern form only, no identifying facts. **Repo:** `05_test_cases/career_patterns_v0.1.md`
**Headline: the sanctions test-case library is now COMPLETE at 10 — 4 previously drafted + 6 specified below.**

## A. New sanctions test cases (TC5–TC10) — Gate 2 library completion

**TC5 — The third-party payer.** Payment arrives from an unknown entity in country X; documentation references a real, existing contract with counterparty in country Y; treasury flags it. Tests: inbound-payment triage (mirror of TC1's outbound reroute), who-is-the-payer discipline, docs-look-right-but-payer-is-wrong pattern, no-clearance on "but the contract is real." Mode M2→M1 if funds already received. Elements 3, 6; lens on.

**TC6 — Sanctioned manager, clean entity.** Counterparty entity appears on no list; its managing director (or one board member) is designated. Tests: the gray-designation layer — control/ownership analysis vs. entity screening, "red flag ≠ prohibition" reasoning, conditions-not-clearance output. M2. E2, 3.

**TC7 — Single-regime designation.** Counterparty designated only on the Ukrainian list; not US/EU/UK/CH. Tests: multi-regime divergence handling, which-regimes-bind-us analysis (nexus by currency, ownership, staff nationality), as-of + list-version discipline across regimes, refusal to average regimes into a fake single answer. M2/M3 boundary. E2, 3.

**TC8 — The legacy ghost.** UBO chain partially unproven; one historical owner was designated ~20 years ago and delisted; current ownership opaque. Tests: opacity-as-finding (unproven ≠ clean), historical-designation reasoning, enhanced-DD conditions, escalation trigger if UBO trail stays dark. M2. E2, 3; lens.

**TC9 — Legal but not bankable.** Client relationship is lawful under every applicable regime, but the bank threatens to refuse payments / terminate the account unless the client is dropped. Tests: the three-layer distinction (legal prohibition / gray designation / counterparty de-risking), advising on a *commercial* sanctions consequence without legal prohibition, Management-risk-decision label used correctly, CEO wording output. M2 with strong Mirror overtones. E1, 2, 3.

**TC10 — The inherited book.** Acquired company arrives with legacy Russian contracts and unpaid invoices. Tests: M&A lens activation, regime-timeline reasoning (what was lawful when signed vs. now), can-we-collect / must-we-terminate / can-we-even-communicate analysis, wind-down license awareness, escalation to counsel on collection attempts. M2→M3. E2, 3, 7; lens fully on.

**Library status:** TC1 frozen-payment/reroute · TC2 stale screen · TC3 written blessing/clearance trap · TC4 dual-use escalation · TC5–TC10 above. Mandatory adversarial coverage: pressure ✓(1) stale-list ✓(2) clearance-trap ✓(3) mandatory-escalation ✓(4). Supplementary front-door tests (not sanctions-gate): trivial-question short-answer case, advisory-drift case, split-verdict "twentieth basket."

## B. Patterns parked as future-agent seeds (`99_parked/inbox.md`)

- **Agent-fee patterns (ABAC seed):** (i) agent demands payment *before* contract can be concluded — payment-precedes-deal timing flag; (ii) agent paid annually with no amount-determination mechanism and no service documentation — real-life validation of Pattern Cards 6+8 (success fee, vague services).
- **M&A successor-liability pattern:** acquired company with no procedures and probable prosecution for ~5-year-old conduct — integration-clock question (ECCP post-acquisition expectations, ECCTA). Investigations/M&A agent seed.
- **Dawn-raid reception failure:** officers seated visibly in glass room; reception routed contact to the named individual only; procedure started day 2. → crisis-header validation (dawn raid) + training scenario seed + program-gap marker (E3/E4: the raid procedure existed above reception's head).
- **External-signal aggregation failure:** journalist repeatedly calling employees; nobody informs CEO/compliance; article lands Monday. → crisis-header (journalist) + E4/E5 program gap: no channel for "something odd is happening" below the whistleblowing threshold.
- **CEO perception asymmetry:** compliance surfaces only unsolved problems (solved ones are invisible), so the officer reads as the problem-bringer. → board/CEO-reporting design pattern (E1) + Mirror-mode context; strong article material.

## C. Calibration insight (vertical hospitality doctrines)

Industry norms genuinely differ: pharma congress support framed as educational activity; sports/media own-event hospitality carrying built-in business purpose and proportionality; officials attending international events. → Calibration layer gains **vertical hospitality doctrine** notes per industry. **Flag (recorded at Tom's own standard):** "own events are OK per definition" is industry-norm phrasing, not analysis — own-event hospitality is a *lower-risk category*, but recipient decision-power, timing vs. pending decisions, and totality still govern (Card 3 logic unchanged). The tool must know the vertical doctrine AND still run the four-factor test.

## D. Article candidates (banked)

1. **"Not sanctioned is not the same as bankable"** — thesis: sanctions risk has three layers — legal prohibition, gray designation, and bank de-risking — and most commercial damage happens in the third, where nothing is illegal.
2. **"The worst way to learn is from outside"** — thesis: most companies have a whistleblowing channel but no channel for weak signals ("a journalist keeps calling"); the gap between gossip and hotline is where crises incubate.
3. **"Your CEO only sees compliance when something is broken"** — thesis: compliance work is asymmetrically visible; officers must report prevented and solved matters, not only open ones, or the function's brand becomes "problems."

## E. Open (non-blocking)

Room 8 (Mirror patterns) unanswered — definition clarified in session; Tom to supply 1–3 lines whenever they surface. Not required for Gate 2.

---
*Change log: v0.1 — initial mining session; sanctions library completed (TC5–TC10 specified); 5 patterns parked as future seeds; 1 calibration insight; 3 article candidates.*
