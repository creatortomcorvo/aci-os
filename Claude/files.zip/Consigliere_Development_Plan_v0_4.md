# Compliance Consigliere — Development Plan v0.4
**Owner:** Tomasz Kruk, Zug (CH) · **Status:** Subordinate to Blueprint v0.1. If this document and the Blueprint conflict, the Blueprint wins until formally amended.
**Purpose:** the standing instruction set for the whole 36-month effort: what the software does, how it is built, how it measures itself, how the content engine runs alongside it, and how new ideas enter without breaking it. Paste-ready as governing instructions for the build environment.
**Horizon:** ~36 months. Year 1 = build + self-use. Year 2 = external validation + audience. Year 3 = first revenue test. Money is an output of Year 3, not an input to Year 1.

---

## 1. What the software is

A methodology-first decision-support system for the under-resourced compliance leader of a mid-size international company. It reduces uncertainty through structured professional reasoning. It is **not** legal advice, not a screening engine, not a policy repository, and it never clears anything.

**The user (refined v0.4):** Head of Compliance, Ethics & Compliance Manager, **or General Counsel / legal counsel carrying the compliance hat** — in mid-size international companies the compliance function frequently sits inside Legal, and that dual-hat counsel is squarely in scope. Common profile: team of 0–2, global exposure, no daily senior sparring partner.

**Working assumption about the user:** intelligent and experienced; knows what a compliance program is; does not need a textbook. The gap is **operational judgment under pressure** — prioritization, escalation logic, "what do I do first." The software never lectures; it helps the user act.

**North Star test (verbatim, Blueprint §10):** if a Head of Compliance used this at 22:30, alone, facing a decision affecting their company, career, or integrity — would they finish feeling they *thought better*, not just that they got an answer? Yes → keep. No → redesign.

---

## 2. What the software does — functional specification

### 2.1 The five mandatory behaviors (every interaction, every agent, no exceptions)

1. **Calm first.** For crisis-pattern inputs (dawn raid, freeze, allegation, regulator contact), the first output is a ≤30-second stabilizing response: "this is manageable" + 3–6 first priorities + an explicit **"Do not"** list (3–5 items: the actions that make crises worse — informal confrontation, deletion, speculation, broad discussion). Only then triage.
2. **Triage before answers.** 3–5 sharp questions before any substantive analysis. First routing question is never "what law applies?" — it is "which of the 7 program elements is under stress?"
3. **Layered depth, user-pulled.** L1 one-minute direction (default terminal state) → L2 professional reasoning → L3 sources with as-of dates → L4 formal memo/report from the dual-audience template set. The system never pushes a deeper layer than requested.
4. **Epistemic categories, always labelled:** Confirmed facts / Assumptions / Inferences / Gaps / Required actions. No analysis ships without this block.
5. **No-clearance rule.** The system never states or implies that anything is "cleared," "safe," or "compliant." No-list-hit ≠ clearance — stated explicitly in every sanctions-type output. Every output distinguishes *established guidance* / *professional judgment* / *uncertainty*.

### 2.2 Element visibility
Every substantive output carries a one-line **"Program elements involved"** tag mapping the situation to the 7-element model. The routing already happens internally; making it visible teaches program architecture through real work and auto-feeds the statistics in §5.2.

### 2.3 Escalation behavior
Hard escalation triggers (output = "stop; this needs external counsel / a human decision-maker," one-line reason): potential criminal exposure of identifiable individuals · privilege-sensitive situations (active investigation, litigation hold, regulator contact) · facts suggesting the user seeks blessing for a decision already made · jurisdictional conflict the frameworks don't resolve · any request for a "clearance." Escalations are logged as first-class events; escalation precision is a quality metric, not a failure. The trigger set is seeded from Tom's own lived escalation moments, abstracted to pattern form (see Track A, Stage 2 prep).

### 2.4 Time-integrity rules (sanctions-critical, applied globally)
Every output referencing lists, thresholds, or guidance carries an **as-of date**; sanctions outputs carry a **list-version reference**. The test library permanently contains a stale-list / regime-change scenario. Answers past shelf life (sanctions 30 days, other guidance 180 days) are flagged stale on re-use. *This rule applies to Tom's public assets too: no stale regulatory bot or article stays published undated (see Track C).*

### 2.5 Calibration profile (minimal version only)
One static profile file: company size band, industry, footprint countries, reporting line, compliance team size, key systems (hotline, screening, LMS), and regional framework vocabulary (CMS/IDW PS 980 for DACH · adequate procedures for UK · ECCP/FCPA for US-connected — identical reasoning, adapted labels). Nothing dynamic, no learning from matters, no organisational memory — parked per Blueprint §8.4/§9.

### 2.6 Explicit not-do list (behavioral)
The software must refuse to: clear/approve anything; give legal advice; store or reason over identifiable client/employer facts; output without the epistemic block; skip triage on a new matter (unless the user says "just draft it"); answer a crisis prompt with an 11-page memo; lecture an experienced user on basics (failure class F9).

---

## 3. Architecture

- **Platform-agnostic core.** Everything lives as markdown + JSON in the repository (Blueprint §6). GPTs, Claude Projects, future app = disposable interfaces. **Canonical version control rule:** the methodology never lives only inside a chat tool's configuration; the repo is the single source of truth, and any GPT/Project is rebuilt from it, not vice versa.
- **One skeleton, inherited.** Every agent = data model → decision engine → QA loop → dual-audience output templates. Sanctions is the reference implementation; no agent gets bespoke architecture.
- **Single front door.** The Consigliere (general triage/routing layer) is the eventual entry point. Until Gate 2 passes, only Agent #1 exists.
- **Scope vs. sequence (settled):** the *product* covers the full compliance domain — ABAC, fraud, investigations, conflicts, competition and beyond. The *build* proceeds one agent at a time; Agent #2 is selected by decision-journal frequency data (Stage 6), not enthusiasm.
- **Separation of knowledge and reasoning.** Frameworks are data; the method (triage patterns, escalation logic, prioritization heuristics) is the IP. Sources inform reasoning; they are never quoted mechanically as the answer.
- **Private-by-design self-use.** Daily use at work means real matters approach the tool: private environment, pattern-abstraction habit before anything is typed, no real client/employer facts in any hosted tool, journal and logs stored locally under Tom's control.

---

## 4. Track A — Build (stages and gates)

Stages advance only through gates. A failed gate means fix or redesign — never "proceed anyway."

### Stage 0 — Preconditions *(OPEN, blocking)*
Employment contract review: IP ownership, side-activity clause, conflict disclosure. Blocks: any external exposure, any publishing (Track C), the friend cohort, all of Track D. Related hygiene (same session as the contract read): kruk.ch site title fix; Tech Lab bots updated, archived-and-dated, or removed; check what the public custom GPT exposes. *A compliance director building a compliance product must be cleaner than clean.*

### Stage 1 — Foundation *(current · target: Months 1–2)*
Foundation Map: ≤10-page synthesis + crosswalk of 8 anchor frameworks against the 7-element model. Resolve the three documented tensions. **Annex A:** 12-element practitioner model must map into the 7 with no orphans (watch: advice-channel mapping → expected Elements 3+4, footnote treatment like the incentives/discipline split).
**Gate 1 exit:** (a) 7-element model survives without an eighth element; (b) three tensions resolved and documented; (c) open decisions logged (OFAC as anchor; cross-cutting third-party/M&A lens); (d) Annex A maps with no orphans.

### Stage 2 — Sanctions Agent v1 *(target: Months 2–4)*
**Prep step (one 20-minute session, before writing cases):** mine 15–20 situation *types* from Tom's own career — partner networks selling in 100+ countries, distributor DD in CEE/CIS, dawn raid, CIA remediation, hotline launches, disclosure regimes — pattern form only, never facts. This list seeds simultaneously: the 10-case library, the triage question bank, and the escalation triggers (§2.3).
Consolidate artifacts into `02_agents/sanctions/`. Build the 10-case synthetic library (must include: stale-list, regime-change, clearance-trap, mandatory-escalation cases). Run, log every failure, iterate.
**Gate 2 exit:** 10/10 pass QA; triage-first verified per case; L1→L4 works; dual-audience output from one data model; zero clearance-language leaks; instrumentation (Track B) live before daily use begins.

### Stage 3 — Real-pattern validation *(target: Months 4–6)*
Anonymised patterns from past casework (structure only). 2–3 trusted peers test **blind, pattern-only** — outputs, not tool access.
**Gate 3 exit:** 22:30 test answered "yes" by peers; no critical-class failures in final run.

### Stage 4 — Production self-use *(the long phase: Months 4–14, overlapping Stage 3)*
Tom uses the tool as his actual daily sparring partner. Rules: decision journal for **every real use** (two minutes, non-negotiable) · monthly mini-review + quarterly calibration review (Track B) · monthly article rhythm runs in parallel (Track C) · no new agents, apps, or branding unless a quarterly review formally reopens the question.
**Gate 4 exit (before any external user):** ≥60 journaled real uses; override rate trending down two consecutive quarters; zero confidentiality incidents; escalation triggers fired correctly in every applicable case.

### Stage 5 — Friend cohort *(target: ~Month 12–14)*
1–2 trusted peers, real access, free. **Selection profile:** small-team international operator — Head of Compliance or dual-hat GC in a company of roughly CHF/EUR 0.5–5bn turnover, genuine cross-border exposure, team of 0–2, no daily sparring partner; pharma/life-sciences or sports/media preferred; DACH-centric. Onboarding pack (signed): confidentiality + pattern-abstraction rules, calibration profile, journal template, "what this tool will never do" sheet. **No journal, no access.** Monthly 30-minute debrief; failures enter the shared log, tagged by user.
**Gate 5 exit:** both testers pass the 22:30 test unprompted; element-frequency distributions compared to Tom's (first generalization evidence); zero confidentiality incidents.

### Stage 6 — Second agent *(target: Months 15–20)*
Selection criterion: highest frequency in the combined decision journals — the data chooses. Expected candidates given Tom's seat: ABAC or Investigations. Must reuse the skeleton unchanged; if it can't, that is an architecture failure → return to Gate 2 logic.

### Stage 7 — Commercial test *(Months 24–36; parked until triggers fire)*
Triggers to reopen: Stage 0 legal position permits; ≥2 agents proven; audience test (Track C) shows real pull. First test, per parked notes: ~10 founding memberships offered to the warmest of the network. Ten yeses = product business. Fewer than five = advisory-led path (practice powered by the tool) — believe the market either way. Full contents of `99_parked/commercial_notes.md` in §7 / Track D.

---

## 5. Track B — Instrumentation and learning system

Live from Gate 2 onward. Core deliverable, not an add-on: after the self-use years, **the logs — not the code — are the unique asset** (no competitor owns a longitudinal record of what a real Head of Compliance actually needs).

### 5.1 Decision journal (`06_qa/decision_journal.md`) — one line per real use, pattern form only
| Field | Content |
|---|---|
| Date | — |
| Element(s) | 1–7 |
| Pattern | abstract situation type, never identifiable facts |
| Depth reached | L1/L2/L3/L4 |
| Tool performance | helped / partially / failed (one clause why) |
| Override | did judgment override the tool? what was the delta? |
| Escalated | yes/no; correctly? |
| Follow-up | article candidate / test case candidate / methodology fix / none |

### 5.2 Usage statistics (monthly)
Frequency distribution across the 7 elements (the most commercially valuable dataset; auto-fed by §2.2 tags) · depth-level distribution (tests the L1-default hypothesis) · time-of-day pattern (tests the 22:30 thesis) · session length · triage questions asked vs. skipped.

### 5.3 Question bank analytics (`01_methodology/triage_stats.md`)
Per triage question: asked / answered / skipped / "don't know." Questions that never change the recommendation get cut; gaps judgment later needed get added. The question bank is versioned like code.

### 5.4 Failure log (`06_qa/failure_log.md`) — fixed taxonomy
F1 hallucinated/mis-dated source · F2 stale list/missed regime change · F3 wrong element routing · F4 overconfidence (judgment presented as established guidance) · F5 missed mandatory escalation · F6 clearance-language leak · F7 depth violation · F8 epistemic block missing/mislabelled · F9 textbook lapse. Severity: critical (F2, F5, F6 always) / major / minor. Critical failures block gate passage regardless of pass counts.

### 5.5 Review rhythm
- **Monthly mini-review (20 min):** journal skim, stats snapshot, pick next month's article from the candidate list, empty the inbox into act/park/discard verdicts *at quarterly reviews only* (until Stage 4: per session, per Hard Constraint 6).
- **Quarterly calibration review (one page, versioned):** methodology changes → new version + change-log line · test cases added from real patterns · triage-bank edits · article candidates consolidated · explicit decision whether anything parked gets reopened (default: no).

---

## 6. Track C — Content engine and audience (the monthly article)

**Purpose:** by the time the product asks anyone for money (Year 3), the audience must already exist. The 5,000 LinkedIn connections are an *untested* asset; this track is the test.

### 6.1 The rhythm
- **One article per month, drafted from build by-products only.** Source = the "→ article candidate" list that sessions generate automatically. No article requires new research; each is the exhaust of methodology work (Blueprint §0: articles are exhaust, not a workstream). Budget: ≤3 hours/month — roughly one week of the daily 20 minutes. If an article needs more, it's the wrong article this month.
- **Drafting starts Month 1. Publishing starts only after Stage 0 clears** — drafts accumulate in `07_articles/` until then. After Stage 0: publish monthly, kruk.ch blog as home, LinkedIn as distribution.
- Every published article carries a date and, where it touches regulation, an as-of reference (§2.4 applies to Tom's public output too).

### 6.2 The pipeline (already banked from sessions to date)
1. "I built four compliance chatbots before I understood what compliance officers actually need" — knowledge bots vs. judgment structure; the difference is architectural.
2. "Why an AI sanctions tool must never say 'cleared'" — the no-clearance rule as design principle.
3. "Triage before answers" — the questions an experienced colleague asks first.
4. "European compliance officers don't have a knowledge gap — they have a judgment gap" — controls-to-risk mapping and escalation judgment are the scarce skills. *(Stats cited must be re-verified first.)*
5. "I logged every compliance decision I made for a year" — the element-frequency reality vs. vendor assumptions. *(Publishable in Year 2, after Stage 4 data exists.)*
6. "Your AI compliance tool won't replace your judgment — it will scale it."
Candidates 7+ accumulate via the content-engine rule in project instructions.

### 6.3 The audience test (Months 6–12 of publishing)
Measure per article: meaningful comments/DMs from target-profile practitioners (not likes) · inbound conversations started · warm-list growth. Decision data: 5,000 connections producing 30+ real conversations = audience; producing only likes = contact list, and Track D shifts advisory-led. Maintain a simple warm-list count (target-profile practitioners who engaged substantively); this list feeds Gate 3 reviewers → Stage 5 cohort → Stage 7 founding members.

### 6.4 Boundaries
No product marketing, no teasers, no "coming soon" — principles only, until Stage 7 triggers fire. The articles build authority, not hype. LinkedIn activity beyond the monthly article + normal professional presence: none required, none planned.

---

## 7. Track D — Commercial (parked; captured, not worked)

Contents of `99_parked/commercial_notes.md` as of v0.4 — reopened only by Stage 7 triggers or a quarterly review:

- **Geography:** Western Europe is the primary market (willingness to pay, procurement maturity, regulatory pressure). DACH first within it — CMS vocabulary, Tom's ground. Eastern Europe: real market, tiered/lower pricing, and note the status dynamic — a Swiss/Zug-based product and a Swiss-based expert carry weight there; CH provenance is a trust asset, not just an address. (Use carefully: provenance claims must stay factual.)
- **Positioning line:** "structured judgment for difficult compliance decisions" — not an encyclopedia, not a database. Do not lead with "compliance program."
- **Swiss positioning:** Zug base, Swiss quality/discretion connotations, EU-adjacent neutrality — worth real money in trust-sensitive purchases; formalize when branding opens.
- **Segments:** four-segment map (architects / small-team operators / inheritors / specialists); Segment 2 first; **dual-hat GC/legal counsel explicitly included in Segment 2** (v0.4).
- **Vertical authority:** pharma/life sciences first (~17 years, provable), sports/media second (current seat, attractive niche), financial services foundation (AIG) as third card.
- **Buyer framings to test:** GC/CEO-as-buyer ("your solo compliance function is a single point of failure"); founding-membership model (~10 × CHF 1,500–2,500/yr); advisory-led practice with software leverage (the "pension model" — the graceful-failure path that still works if SaaS never scales).
- **Market evidence:** Eurostat enterprise counts, Deloitte DACH 2025, PwC 2025, NAVEX 2025 — all unverified secondary citations; re-verify before any external use.

---

## 8. QA regime

Synthetic-only test data until Stage 3; pattern-abstracted thereafter — no real matter, ever, in any test asset. Every methodology version change reruns the full case library (regression). Per-output QA checklist: epistemic block · as-of date · element tag · layer discipline · no clearance language · escalation triggers evaluated · dual-audience consistency. Permanent adversarial cases: clearance trap · "CEO needs it in 10 minutes" · stale list · privileged matter.

---

## 9. KPIs

| Track | KPI | Target |
|---|---|---|
| A/2 | QA pass rate, 10 cases | 10/10, zero critical |
| A/4 | Journal completion | 100% of real uses |
| A/4 | Override rate | downward, 2 consecutive quarters |
| A/4 | L1-sufficiency | >50% of sessions end at L1 |
| A/4–5 | Escalation precision | no F5 ever; false positives reviewed quarterly |
| A/5 | 22:30 test | unprompted "yes," both testers |
| A/5 | Cross-user element correlation | documented (discovery, no target) |
| C | Article cadence | 1/month drafted; published monthly post-Stage 0 |
| C | Audience signal | meaningful conversations per article, warm-list growth (counted, no vanity metrics) |

---

## 10. Living-document mechanics (how new ideas enter)

1. **Inbox first.** Every new idea, external document, AI transcript, or market thought lands in `99_parked/inbox.md` — one line each. Nothing is lost; nothing jumps the queue.
2. **Verdicts on a rhythm.** Act / park / discard verdicts happen at monthly mini-reviews (light) and quarterly calibration reviews (full), per Hard Constraint 6. Until Stage 4 begins: per-session verdicts with explicit Blueprint check.
3. **Versioning.** Any change to this plan = new version number + one change-log line. New chapters are added at the end of the relevant Track, never by rewriting gates already passed.
4. **What can never enter via this mechanism:** changes to the 7-element model, the five mandatory behaviors, the no-clearance rule, or the gate sequence — those require an explicit Blueprint amendment, considered only at a quarterly review.

---

## 11. Hard constraints (non-negotiable)

1. No real client/employer data in any consumer AI tool, ever. Pattern abstraction first.
2. Stage 0 blocks all external exposure — publishing, cohort, marketing, revenue — until closed.
3. Decision support, not legal advice; the no-clearance rule is architectural, not cosmetic.
4. Organisational memory, additional agents, apps, Stress Mode, branding, revenue: parked per Blueprint §9; reopened only by review, in writing.
5. Methodology → Product → Brand. Nothing built for a later pipeline stage before the earlier one is written down.
6. External-input discipline: inbox first; absorption only at reviews; urgency is not a gate pass.
7. Time budget honesty: ~20 min/day ≈ 10 hrs/month. Track A has priority; Track C gets ≤3 hrs/month; anything that doesn't fit moves to next month rather than expanding the budget silently.

---

## 12. 36-month overview

| Months | Track A (build) | Track B (data) | Track C (content) | Track D (commercial) |
|---|---|---|---|---|
| 1–2 | Stage 0 + Gate 1 | — | draft #1–2 (unpublished) | parked |
| 2–4 | Stage 2 → Gate 2 | goes live | drafts accumulate | parked |
| 4–6 | Stage 3 → Gate 3 | journal running | **publishing starts** (post-Stage 0) | parked |
| 4–14 | Stage 4 self-use | monthly + quarterly rhythm | 1 article/month; audience test | parked |
| 12–14 | Stage 5 cohort → Gate 5 | cross-user data | continue | parked |
| 15–20 | Stage 6 second agent | continue | continue (now with Stage 4 data articles) | parked |
| 24–36 | — | continue | continue | **Stage 7 trigger check: founding-member test or advisory-led pivot** |

---

*Change log:*
*v0.1 — initial; extended Blueprint §7 into self-use, cohort, instrumentation.*
*v0.2 — absorbed market analysis: user assumption, Do-not list, element tag, regional vocabulary, F9, Annex A, cohort profile, parked-notes inventory.*
*v0.3 — Hard Constraint 6 (external-input discipline).*
*v0.4 — comprehensive consolidation: 36-month horizon + calendar (§12); four-track structure; Track C monthly article engine with banked pipeline + audience test; dual-hat GC/legal counsel added to user definition (§1) and Segment 2; Track D expanded (Western Europe primary, EE tiered pricing, Swiss/Zug positioning, pharma-first authority); Stage 2 career-pattern mining prep step; Stage 0 expanded with public-asset hygiene; canonical-repo rule (§3); living-document mechanics (§10); Hard Constraint 7 (time-budget honesty). Gates unchanged. Gate 1 status unchanged (open).*
