# Gate 1 — Resolution Record v1.0
**Date decided:** 04 July 2026 · **Decided by:** Tomasz Kruk · **Status:** All five Gate 1 decisions CLOSED. Gate formally completes when Foundation Map v1.0 absorbs the items below (one mechanical drafting task, assigned to Codex; no further decisions required).
**Repo location:** `00_foundation/gate_1_resolution_record_v1.0.md`

## The five decisions

**D1 — Incentives & discipline: KEEP the split across Elements 1 and 7.**
Consequence management lives twice by design: board-level accountability and tone (Element 1, Governance & Tone) and post-finding disciplinary mechanics (Element 7, Response & Remediation). Documented as a deliberate dual-home with a footnote in the Foundation Map. Rationale: USSG §8B2.1 itself splits the concept; forcing a single home would fail the crosswalk against the anchor that defines it.

**D2 — AI/emerging-technology risk: YES — risk row in Element 2, control row in Element 3. No new element.**
Per ECCP (Sept 2024): AI is a risk to be assessed (E2) and a control medium to be governed (E3) — including monitoring AI against intended purpose and a baseline of human decision-making. The control-medium dimension (Core Spec §9) reinforces: AI is how controls are implemented, not a program pillar.

**D3 — Third-party/M&A cross-cutting lens: FORMALLY APPROVED.**
Definition (to appear verbatim in Foundation Map): *a lens is a mandatory question set applied across elements rather than an element itself; the third-party/M&A lens attaches to Elements 2 (risk), 3 (controls/DD), and 6 (ongoing monitoring), and activates whenever an external party or transaction is in scope.* Converts two years of habit into architecture.

**D4 — Annex A advice-channel mapping: ACCEPTED. The 12-element practitioner model maps into the 7 with no orphans.**
The one contested function — the advice & guidance channel — maps three ways: existence and staffing of the channel → Element 3 (a standard/control); its usage, accessibility, and quality → Element 4 (Training & Communication); its inquiry data → Element 6 (Monitoring & Data). Footnote treatment, same as D1. All other 12→7 mappings were uncontested (procedures+policies → E3; investigations+speak-up → E5; third-party → the D3 lens). **Consequence: the 7-element model survives its strongest challenge to date. The backbone stands. Any future challenge to the model requires a failed crosswalk, not a preference, and proceeds only as a formal Blueprint amendment.**

**D5 — OFAC Framework for Compliance Commitments: ADOPTED as the eighth anchor source.**
Rationale: Agent #1 is Sanctions; a Foundation Map excluding the sanctions regulator's own compliance framework would be indefensible in front of exactly the practitioners the product serves. Anchor set is now final at eight: DOJ ECCP (2024) · FCPA Resource Guide + 2025 enforcement guidelines · UK Bribery Act six principles · ECCTA failure-to-prevent-fraud · ISO 37301/37001 · USSG §8B2.1/OIG · OECD Good Practice Guidance · OFAC Framework. Second-ring sources (cited, not crosswalked): EU AI Act, ISO/IEC 42001, GDPR.

## Remaining mechanical task (Codex, no decisions involved)
Foundation Map v1.0: add the OFAC crosswalk column · insert D1 and D4 footnotes · insert the D3 lens definition paragraph · add the D2 rows to Elements 2 and 3 · attach Annex A (12→7 table) as decided. On completion, mark Gate 1 CLOSED in PROJECT_DISCIPLINE.md and WHERE_ARE_WE.md.

## Updated phase block (paste into Project Instructions)
> **Phase:** Stage 2 — Sanctions Agent v1 toward Gate 2 (Stage 4 journal running in parallel)
> **Stage 0a (CLOSED, 04.07.2026):** private build permitted — hobby basis, own time/equipment, no employer resources or data. Memo on file.
> **Stage 0b (OPEN):** employer approval required before any commercial/external step. Checked at Stage 3/5 entry — no per-session reminders.
> **Gate 1 (DECIDED 04.07.2026):** five resolutions per Gate 1 Resolution Record v1.0; closes fully on Foundation Map v1.0 integration (mechanical).
> **Gate 2 (ACTIVE — the work):** 4 of 10 test cases drafted; next session = career-pattern mining (15–20 situation types) to seed the remaining 6; then formal 10-case run.
> **Stages 3 & 5 (BLOCKED):** by 0b + Gate 2. Pilot spec parked with activation lock.

---
*Change log: v1.0 — Gate 1 decisions D1–D5 recorded and closed; anchor set finalized at eight; 7-element backbone confirmed against Annex A; Foundation Map integration task assigned.*
