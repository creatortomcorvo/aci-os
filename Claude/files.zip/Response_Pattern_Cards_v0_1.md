# Response Pattern Cards v0.1 — 15 cases from the Question Inventory
**Location:** `01_methodology/response_pattern_cards_v0.1.md` · **Status:** methodology artifact. These are compressed design specs, not full outputs. Full dual-speed treatment is reserved for the Sanctions Agent's 10-case library (Stage 2). Each card: opening move → direction → do-nots → decisive questions → if–then → trap named.
**Mode legend:** M1 Crisis (dual-speed) · M2 Judgment call · M3 Counsel-boundary · M4 Program self-assessment · M5 Escalation-mandatory

---

## M1 — CRISIS

### Card 1 · Facilitation demand / extortion (Q22)
**Q:** "An official demands a small payment to release our equipment / clear customs / allow event access. What do we do?"
**Opening (Speed-1, pre-written):** "An official demanding payment to do their job — known pattern, and the law treats your situation more kindly than your panic suggests. → Don't pay yet unless someone's safety is at risk. → Don't negotiate the amount — negotiating converts extortion optics into bribery optics."
**Direction:** distinguish the only true exception first: genuine threat to life/liberty/safety → pay, document immediately, report internally same day. Everything else: refuse politely, ask for the demand in writing (they almost never will), escalate locally, use the delay.
**Decisive questions:** Is anyone's safety at risk right now? · What exactly is being withheld and is there a lawful express route/fee with a receipt? · Has this checkpoint/office done this before (pattern → different playbook)?
**If–then:** If safety risk → pay, contemporaneous record, report today; this becomes a books-and-records task, not a secret. If purely commercial pressure → no payment; the deal absorbs delay or the deal was mispriced.
**Trap named:** urgency is the extortionist's product. The demand is engineered to feel like an exception.
**Elements:** 3, 5, 7.

### Card 2 · Dawn raid / regulator contact (Q29)
**Q:** "A regulator/prosecutor just contacted the business / is at reception. First 24 hours?"
**Opening (Speed-1):** "Regulator at the door — the most rehearsed crisis in compliance, which means a script exists and you only have to run it. → Don't let anyone speculate, explain, or volunteer beyond what's asked. → Don't touch, delete, or 'tidy' anything — preservation starts this second."
**Direction:** cooperate + preserve + narrow the channel: one coordinator, counsel called before substantive engagement, scope of the authority's mandate read and copied, parallel log of everything taken/asked.
**Decisive questions:** What does the warrant/request actually cover — read it? · Who is the single point of contact and does everyone know it's them? · Is external counsel already moving?
**If–then:** If employees are being interviewed on the spot → they may have counsel present; nobody is obliged to speculate. If the scope is exceeded → note it, don't obstruct it; the objection is for lawyers later, not corridors now.
**Trap named:** the urge to appear maximally helpful — over-cooperation creates records no one can un-create.
**Elements:** 5, 7, 1.

---

## M2 — JUDGMENT CALLS

### Card 3 · Hospitality package for officials (Q12)
**Q:** "Can we approve VIP tickets + travel + hotel for a federation/government contact?"
**Opening (pattern line):** "Hospitality for a decision-maker — the question is never the ticket, it's the timing and the totality."
**Direction:** decompose into the four dimensions that decide it: recipient's decision power over you · proximity to a pending decision (tender, renewal, permit) · proportionality vs. business purpose · transparency (recipient's employer knows? recorded openly?). Approve, condition, or decline per the combination — never per the item.
**Do-nots:** don't evaluate the package as a lump ("it's just tickets") · don't rely on "everyone in this industry does it" · don't approve verbally what you wouldn't write.
**Decisive questions:** What decision affecting you does this person influence in the next 12 months? · Would their employer/authority approve if asked directly? · Who else attends — is there a genuine business program or only the match?
**If–then:** If a tender/renewal is live → default no; hospitality waits for decisions to close. If recipient is a public official → their own rules cap you, not yours.
**Trap named:** industry-norm bias — "standard in sports" is a market observation, not a legal category.
**Elements:** 3, 2. Cross-cutting lens if a third party pays or hosts.

### Card 4 · Travel for officials (Q13)
**Q:** "Can we pay flights/hotels/per diems for officials attending our event/inspection/bid presentation?"
**Opening:** "Paying for an official's journey — legitimate promotional expense and classic bribery vehicle share this exact shape; the controls decide which one you're holding."
**Direction:** the defensible version has fixed anatomy: direct business purpose (they must see something of yours) · economy-standard, no companions, no cash per diems, no side-tourism · paid to vendors not persons · invited via the institution, not the individual · documented before, not after.
**Do-nots:** don't wire anything to personal accounts · don't add "free days" · don't let sales pick the hotel category.
**Decisive questions:** Why must this person physically attend — what fails if they don't? · Institution invited or individual? · Any pending decision they touch?
**If–then:** If cash per diems or companion travel appear → stop; that's the line between promotion and gift. If their institution has hosting rules → those rules are the ceiling.
**Trap named:** incrementalism — each upgrade is small; the total is the offense.
**Elements:** 3, 6 (records).

### Card 5 · Donation/sponsorship near a decision-maker (Q15)
**Q:** "Can we sponsor a foundation/academy/club connected to an official or customer decision-maker?"
**Opening:** "A good cause with a powerful patron — the cause is real, the patron is the risk, and both facts are true at once."
**Direction:** treat as indirect-benefit analysis, not charity approval: who asked, who benefits reputationally, what's pending. Defensible shape: unsolicited by the decision-maker, paid to the institution with governance, no naming/credit flowing to the patron, cooling distance from any pending decision, published openly.
**Do-nots:** don't route via the official's "suggestion" unexamined — the suggestion is the red flag · don't book as marketing if it's a donation (Q24 shadow) · don't let the timing sit inside a tender window.
**Decisive questions:** Who first proposed it? · What does the patron personally gain (credit, photos, board seat)? · What decisions involving you does the patron touch this year?
**If–then:** If proposed by the official/customer themselves → enhanced review, default defer. If foundation lacks audited accounts → funds in kind or not at all.
**Trap named:** halo effect — philanthropy feels self-evidently clean; enforcement files disagree.
**Elements:** 3, 2, 6.

### Card 6 · Success fee for an intermediary (Q17)
**Q:** "Is a 10–20% success fee for this agent defensible?"
**Opening:** "A success fee is a question wearing a number — the number matters less than what success means and who can influence it."
**Direction:** three-part test: (1) what does success depend on — private counterparty or government/federation decision? (2) is the fee proportionate to demonstrable *work*, not access? (3) market benchmark for this service in this geography. Government-touching success + percentage fee = the highest-risk compensation structure in the ABAC universe; if it survives at all, it survives with milestones, caps, audit rights, and paper for every deliverable.
**Do-nots:** don't benchmark against "what they asked for" · don't accept "that's how it works there" as the analysis · don't split the fee into retainer+success to make each half look smaller.
**Decisive questions:** Success = whose signature? · What work product will exist as evidence of services? · Why a percentage rather than fees-for-work?
**If–then:** If success turns on a public/federation decision → escalate to enhanced review regardless of percentage. If no work product can be described → the fee is buying something else; stop.
**Trap named:** anchoring — their 20% makes 12% feel safe. Safety isn't on that axis.
**Elements:** 3, 2. Cross-cutting lens fully engaged.

### Card 7 · Offshore / third-party payment request (Q18)
**Q:** "Agent asks to be paid in another country / to a related company / to an individual. Acceptable?"
**Opening:** "Payment geometry question — the rule of thumb has survived every enforcement cycle: money follows the contract, or the contract follows the money into trouble."
**Direction:** default no to any payee ≠ contracting party, any jurisdiction ≠ where services are rendered/party resides, any individual for a corporate contract. Exceptions exist (group treasury structures) but are *documented before payment*, tax-and-AML reviewed, and never urgent.
**Do-nots:** don't process "just this once" — payment routing exceptions are how books-and-records violations are born · don't let finance own this call alone.
**Decisive questions:** Written, verifiable reason for the routing? · Does the alternative payee appear in the contract? · Who benefits from the opacity?
**If–then:** If the request comes with urgency → urgency + opacity = stop, always. If tax-driven → their tax planning is not your risk to absorb; require their written tax advice in the file.
**Trap named:** helpfulness bias — accommodating a "banking issue" feels like service; it's control-override by courtesy.
**Elements:** 3, 6.

### Card 8 · Vague services contract (Q19)
**Q:** "Is 'strategic advisory / market access / government relations' too vague as a contract description?"
**Opening:** "If you can't tell from the contract what you'd sue them for not delivering, the description is too vague — that's the whole test."
**Direction:** rewrite until three things are enumerable: concrete deliverables, verification method, and what the money maps to. "Relationship management" survives only when decomposed into meetings arranged (logged), introductions made (named), reports delivered (filed).
**Do-nots:** don't fix vagueness with a bigger disclaimer clause · don't sign now intending to "tighten at renewal."
**Decisive questions:** What lands in the file each quarter as proof of service? · Could an auditor reconstruct what was bought from the paper alone? · Why does the counterparty resist specificity?
**If–then:** If they resist enumerating deliverables → that resistance is the finding. If services touch officials → vague + government = enhanced review automatically.
**Trap named:** sophistication mimicry — elegant vagueness sounds senior; it papers over the absence of anything.
**Elements:** 3, 6.

### Card 9 · Discounts/rebates as hidden benefits (Q25)
**Q:** "Could our discounts, credits, free inventory, or comp tickets be treated as improper benefits?"
**Opening:** "Value is value — enforcement stopped distinguishing envelopes from rebates a decade ago; the question is who ends up holding the benefit and why."
**Direction:** trace each mechanism to its true beneficiary and its business logic: volume-justified and booked transparently → commercial; discretionary, person-directed, or off-books → benefit-in-kind analysis applies exactly as to gifts. Comp tickets to a *person* at a customer are hospitality (Card 3 logic), whatever the invoice says.
**Do-nots:** don't let commercial teams classify these unilaterally · don't net benefits against invoices in ways the books can't explain (Q24 shadow).
**Decisive questions:** Individual or entity as end-beneficiary? · Same discount defensible if published to all comparable customers? · How is it recorded — visibly or creatively?
**If–then:** If a benefit is person-directed at a decision-maker → route through the hospitality/gift framework, not the pricing framework. If finance can't book it transparently → it doesn't happen.
**Trap named:** category laundering — moving a benefit into a commercial vocabulary feels like compliance; it's relabeling.
**Elements:** 3, 6.

### Card 10 · Relative-owned supplier / conflict (Q23)
**Q:** "Employee's relative owns a supplier / sits on the customer's tender committee. How do we handle it?"
**Opening:** "A conflict disclosed is a control problem; a conflict discovered is an integrity problem — which one is this, and the answer changes everything downstream."
**Direction:** conflicts are managed, not moralized: remove the conflicted person from the decision path (not necessarily from the company or the deal), document the wall, re-run any decision they already touched with clean hands, and check whether terms drifted from market while the conflict was live.
**Do-nots:** don't punish disclosure — every over-reaction to an honest disclosure teaches the org to hide the next one · don't leave the wall informal ("he knows not to get involved").
**Decisive questions:** Disclosed proactively or found? · What decisions did the conflicted person already influence? · Are the supplier's terms at market?
**If–then:** If discovered (not disclosed) and decisions were touched → treat as a review trigger for those decisions, possibly an investigation (Mode 5 handoff). If disclosed early → thank them visibly; the response is culture-setting (Element 1).
**Trap named:** severity inversion — organizations often punish the disclosure harder than the concealment because the disclosure is the one they can see.
**Elements:** 3, 5, 1.

---

## M3 — COUNSEL-BOUNDARY (the mode that structures the handoff)

### Card 11 · Employee data review across jurisdictions (Q5)
**Q:** "Can we legally review employee emails/Teams/WhatsApp/laptops in this country?"
**Opening:** "This is a question I make better, not one I answer — reviewability is jurisdiction-by-jurisdiction law, and a confident general answer would be the malpractice."
**Direction (briefing structure):** what compliance owns: defining *what* is sought and *why* (necessity/proportionality narrative), the least-intrusive-first sequence (corporate email before chat before device), preservation without review. What counsel owns: local lawfulness, works-council/DPO steps, privilege structure. Deliverable: a one-page review protocol counsel can bless in one call instead of building in five.
**Decisive questions for counsel (not for me):** Which legal basis for each data category here? · Notice/consultation duties before collection? · Can review happen in-country or must data stay local?
**If–then:** If review already started informally → stop it, log when/who/what; sequencing errors compound. If WhatsApp/private devices are in scope → assume the answer is harder and slower everywhere; plan around corporate sources first.
**Trap named:** tool availability bias — "IT can pull it" feels like "we may read it." Capability is not lawfulness.
**Elements:** 5, 3.

### Card 12 · Whistleblower statutory clocks (Q7)
**Q:** "What must we tell the reporter within 7 days / 3 months, and how much can we disclose?"
**Opening:** "Two clocks and a confidentiality ceiling — the structure is EU-wide, the exact content is local law, so here's the frame and the questions that make counsel fast."
**Direction:** frame compliance owns: acknowledge receipt (short clock), substantive feedback on follow-up (long clock), and the disclosure ceiling — you report on *process* ("investigated, measures taken"), never on *people* (no names, no disciplinary specifics; the accused has privacy rights too). Calendar both clocks on day zero, every case, no exceptions.
**Do-nots:** don't promise outcomes to the reporter · don't let the deadline force disclosure of investigation detail — meeting the clock with process language is compliant; over-sharing to seem responsive is a breach in the other direction.
**Decisive questions for counsel:** exact local transposition deadlines/content here? · anonymous-reporter feedback mechanics? · what may be said if the case is ongoing at the 3-month mark?
**If–then:** If the 3-month mark arrives mid-investigation → interim process update satisfies the clock; silence doesn't. If the reporter goes external mid-process → different playbook, counsel same day.
**Trap named:** responsiveness bias — the urge to show the reporter "we're taking it seriously" by sharing details that violate the accused's rights.
**Elements:** 5, 3.

---

## M4 — PROGRAM SELF-ASSESSMENT

### Card 13 · "Was our program effective despite the misconduct?" (Q34)
**Q:** "Can we defensibly say our compliance program was effective even though misconduct occurred?"
**Opening:** "Yes — possibly. Misconduct occurring is not the test; enforcement frameworks explicitly assume programs don't prevent everything. The test is what the program *did*: before, during, after."
**Direction:** build the effectiveness narrative on the three prongs assessors actually probe: design (was this risk assessed, was a control assigned — or is this the 'no controls mapped to the risk' gap), detection (did *your* systems surface it, and how fast), response (investigation, remediation, discipline, disclosure decision — Cards under Q32/33). Honest output = a gap-map, not a verdict: "strong on detection, exposed on risk-to-control mapping" is a usable answer; "yes, effective" is not one I'll produce.
**Do-nots:** don't write the conclusion before the gap-map · don't confuse activity metrics (trainings held) with effectiveness evidence (behavior found and fixed).
**Decisive questions:** Was this specific risk in your assessment with a control against it? · Who detected it — you or someone else? · What changed after (and can you show it)?
**If–then:** If detection came from outside (auditor, regulator, media) → the narrative burden doubles; prioritize showing why internal detection failed and what's rebuilt. If this analysis is for an active enforcement context → Mode 3: counsel frames it, this becomes their briefing.
**Trap named:** defensive certainty — the instinct to answer "yes" quickly is exactly what makes the eventual answer unconvincing.
**Elements:** all seven — this question is the program.

---

## M5 — ESCALATION-MANDATORY

### Card 14 · Self-reporting decision (Q1)
**Q:** "Do we need to voluntarily disclose this to DOJ/SEC/SFO/a regulator/a federation/a tender authority?"
**Opening:** "The most consequential question in the inventory — and the one this tool must not answer. What it can do: make you the best-prepared person in the room where it's decided."
**Direction (thin by design):** disclosure decisions are made by counsel + leadership under privilege, on a factual record. Compliance's job before that room: preserve the record, freeze the timeline (when known, by whom — the clock question that dominates everything), map which regimes could even apply (multiple jurisdictions = multiple calculi), and prepare the decision memo *structure* — never the recommendation.
**Do-nots:** don't type case facts here or anywhere unprivileged · don't let anyone frame it as "disclose or not" binary before counsel maps the regimes — partial/sequenced disclosure paths exist · don't let time pass unlogged: in every regime, *when you knew* is the exposure multiplier.
**If–then:** If any regime with cooperation-credit windows may apply → counsel this week, not this quarter; credit decays. If the underlying conduct may be continuing → that changes everything and outranks the disclosure question itself; counsel today.
**Trap named:** deliberation drift — organizations "gather more facts" as a way of not deciding, and the gathering time becomes the aggravating factor.
**Elements:** 7, 1, 5.

### Card 15 · Allegation against a senior executive (Q10)
**Q:** "The allegation concerns the CEO / a board member / the GC. Who supervises the investigation?"
**Opening:** "The question answers itself once inverted: nobody in the accused's reporting line — including, possibly, you."
**Direction (structural, not investigative):** supervision must sit above and outside the accused's authority: audit committee / board chair for a CEO; independent members for a board member; and if the GC is accused, external counsel reports to the board directly — the normal privilege architecture is itself conflicted. Your own position check is mandatory: if the accused influences your budget, bonus, or role, *say so to the supervising body in writing* — it protects the investigation and you.
**Do-nots:** don't inform the accused before preservation and supervision exist · don't run "preliminary quiet checks" first — with executives, the preliminary check *is* the tip-off · don't let loyalty or fear compress the structure ("the chairman trusts him" is not a control).
**Decisive questions:** Who does the accused *not* control — that's your supervision pool? · Is your own reporting line clean here? · Does D&O / board protocol already prescribe a path (often yes, often forgotten)?
**If–then:** If the accused is your own boss or controls your position → external counsel and board channel, same day; your protection and the investigation's integrity are now the same project. If evidence could be within the accused's reach → preservation precedes every other step, silently.
**Trap named:** authority gradient at maximum voltage — every instinct says "handle it delicately"; the structure exists precisely because instinct fails at this altitude.
**Elements:** 5, 1, 7.

---
*Change log: v0.1 — 15 cards spanning all five response modes, drawn from the 40-question inventory. Full dual-speed outputs remain reserved for the Sanctions Agent 10-case library (Stage 2). Cards for future agents' domains are methodology seeds, not build authorization.*
